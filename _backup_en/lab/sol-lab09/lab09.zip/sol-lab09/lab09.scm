(define (over-or-under num1 num2)
  (cond 
    ((< num1 num2) -1)
    ((= num1 num2) 0)
    (else          1)))

(define (composed f g) (lambda (x) (f (g x))))

(define (repeat f n)
  ; note: this relies on `composed` being implemented correctly
  (if (< n 1)
      (lambda (x) x)
      (composed f (repeat f (- n 1)))))

(define lst
        (cons (cons 1 nil)
              (cons 2 (cons (cons 3 (cons 4 nil)) (cons 5 nil)))))

(define (without-duplicates lst)
  (if (null? lst)
      lst
      (cons (car lst)
            (without-duplicates
             (filter (lambda (x) (not (= (car lst) x)))
                     (cdr lst))))))
