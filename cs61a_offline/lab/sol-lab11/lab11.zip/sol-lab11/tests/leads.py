test = {
  'name': 'leads',
  'points': 1,
  'suites': [
    {
      'type': 'sqlite',
      'setup': """
      sqlite> .read imdb1000.sql
      sqlite> .read lab11.sql
      """,
      'cases': [
        {
          'locked': False,
          'code': r"""
          sqlite> select * from leads;
          Brad Pitt|12
          Tom Cruise|12
          Robert De Niro|12
          Johnny Depp|12
          Leonardo DiCaprio|13
          Tom Hanks|18
          """,
        },
      ],
    },
  ]
}