(define (accumulate merger start n term)
  (if (= n 0)
      start
      (accumulate merger
                  (merger (term n) start)
                  (- n 1)
                  term)))

(define (accumulate-tail merger start n term)
  (define (accum-helper x so-far)
    (if (= x 0)
        so-far
        (accum-helper (- x 1) (merger (term x) so-far))))
  (accum-helper n start))

; ALT solution
(define (accumulate-tail merger start n term)
  (if (= n 0)
      start
      (accumulate-tail merger
                       (merger (term n) start)
                       (- n 1)
                       term)))
