CREATE TABLE parents (parent TEXT, child TEXT);

INSERT INTO parents VALUES
  ('ace', 'bella'),
  ('ace', 'charlie'),
  ('daisy', 'hank'),
  ('finn', 'ace'),
  ('finn', 'daisy'),
  ('finn', 'ginger'),
  ('ellie', 'finn');

CREATE TABLE dogs (name TEXT, fur TEXT, height INTEGER);

INSERT INTO dogs VALUES
  ('ace',     'long',  26),
  ('bella',   'short', 52),
  ('charlie', 'long',  47),
  ('daisy',   'long',  46),
  ('ellie',   'short', 35),
  ('finn',    'curly', 32),
  ('ginger',  'short', 28),
  ('hank',    'curly', 31);

CREATE TABLE sizes (size TEXT, min INTEGER, max INTEGER);

INSERT INTO sizes VALUES
  ('toy',      24, 28),
  ('mini',     28, 35),
  ('medium',   35, 45),
  ('standard', 45, 60);

-------------------------------------------------------------
-- PLEASE DO NOT CHANGE ANY SQL STATEMENTS ABOVE THIS LINE --
-------------------------------------------------------------

-- The size of each dog
CREATE TABLE size_of_dogs AS
  SELECT name, size FROM dogs, sizes
    WHERE height > min AND height <= max;


-- All dogs with parents ordered by decreasing height of their parent
CREATE TABLE by_parent_height AS
  SELECT child FROM parents, dogs WHERE name = parent ORDER BY height desc;


-- Sentences about siblings that are the same size
CREATE TABLE sentences AS
  WITH
    siblings(first, second) AS (
      SELECT a.child, b.child FROM parents AS a, parents AS b
        WHERE a.parent = b.parent AND a.child < b.child
    )
  SELECT "The two siblings, " || first || " and " || second || ", have the same size: " || a.size
    FROM siblings, size_of_dogs AS a, size_of_dogs AS b
    WHERE a.size = b.size AND a.name = first AND b.name = second;
  

-- [Optional] Filling out this helper table is recommended
CREATE TABLE siblings AS
  SELECT a.child AS first, b.child AS second FROM parents AS a, parents AS b
    WHERE a.parent = b.parent AND a.child < b.child;

-- Sentences about siblings that are the same size
CREATE TABLE sentences AS
  SELECT "The two siblings, " || first || " and " || second || ", have the same size: " || a.size
    FROM siblings, size_of_dogs AS a, size_of_dogs AS b
    WHERE a.size = b.size AND a.name = first AND b.name = second;


-- Ways to stack 4 dogs to a height of at least 175, ordered by total height
CREATE TABLE stacks AS
  WITH
    sums(names, total, n, max) AS (
      SELECT name, height, 1, height FROM dogs UNION
      SELECT names || ", " || name, total+height, n+1, height
        FROM sums, dogs
        WHERE n < 4 AND max < height
    )
  SELECT names, total FROM sums WHERE n=4 AND total>=175 ORDER BY total;


-- Ways to stack 4 dogs to a height of at least 175, ordered by total height
CREATE TABLE stacks_helper(dogs, stack_height, last_height, n);

INSERT INTO stacks_helper SELECT name, height, height, 1 FROM dogs;
INSERT INTO stacks_helper SELECT dogs || ", " || name, stack_height + height, height, n + 1 FROM stacks_helper, dogs WHERE height > last_height;
INSERT INTO stacks_helper SELECT dogs || ", " || name, stack_height + height, height, n + 1 FROM stacks_helper, dogs WHERE height > last_height;
INSERT INTO stacks_helper SELECT dogs || ", " || name, stack_height + height, height, n + 1 FROM stacks_helper, dogs WHERE height > last_height;


CREATE TABLE stacks AS
  SELECT dogs, stack_height FROM stacks_helper WHERE stack_height >= 175 ORDER BY stack_height;


-- Height range for each fur type where all of the heights differ by no more than 30% from the average height
CREATE TABLE low_variance AS
  SELECT fur, MAX(height) - MIN(height) AS height_range FROM dogs GROUP BY fur
      HAVING MIN(height) >= .7 * AVG(height) AND MAX(height) <= 1.3 * AVG(height);


-- Heights and names of dogs that are above average in height among
-- dogs whose height has the same first digit.
CREATE TABLE above_average AS
  with averages(digit, mean) AS (
      SELECT height/10, avg(height) FROM dogs group by height/10 having count(*)>1
  )
  SELECT height, name FROM dogs, averages
         WHERE height >= mean AND digit = height/10;


-- non_parents is an optional, but recommended question
-- All non-parent relations ordered by height difference
CREATE TABLE non_parents as
  WITH
    grandparents(grandog, grandpup) AS (
      SELECT a.parent, b.child FROM parents AS a, parents AS b
        WHERE a.child = b.parent
    ),
    ancestors(ancestor, descendent) AS (
      SELECT grandog, grandpup FROM grandparents UNION
      SELECT ancestor, child FROM ancestors, parents
        WHERE parent = descendent
    ),
    relations(first, second) AS (
      SELECT ancestor, descendent FROM ancestors UNION
      SELECT descendent, ancestor FROM ancestors
    )
  SELECT first, second FROM relations, dogs AS f, dogs AS s
    WHERE first = f.name AND second = s.name ORDER BY f.height-s.height;
